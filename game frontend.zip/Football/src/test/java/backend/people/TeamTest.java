package backend.people;

import static org.junit.jupiter.api.Assertions.*;

class TeamTest {

}