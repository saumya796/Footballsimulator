package sample;

public class CenterSpot {

    private final Position spotPosition;
    private int radius;

    public CenterSpot(int radius, Position spotPosition) {
        this.radius = radius;
        this.spotPosition = spotPosition;
    }

}
