package sample;

public class GallCourt {
    private int length;
    private int width;
    private Position centerPosition;

    public GallCourt(int length, int width, Position centerPosition) {
        this.length = length;
        this.width = width;
        this.centerPosition = centerPosition;


    }
}
