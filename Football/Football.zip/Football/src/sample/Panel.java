package sample;

public class Panel {

    int score;


    static void start() {

    }
    static void count() {

    }
    static void countScore() {

    }
    static void end() {

    }
    static void reset() {

    }

}
